package 实验一___词法分析设计;



public class Main{
    public static void main(String[] args) {
        Windows windows = new Windows();
    }
}
